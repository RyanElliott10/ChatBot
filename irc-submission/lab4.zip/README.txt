python ircbot-final.py irc.freenode.net "#CSC482" richa-bot
